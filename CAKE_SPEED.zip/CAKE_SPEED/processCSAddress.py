import pandas as pd
import os
from datetime import datetime,date

today = str(date.today())
filepath = os.path.abspath(os.path.dirname(__file__))
filepath = os.path.join(filepath, "excel")
Newfilepath = os.path.join(filepath, "SortedByAddress_" + today + ".xlsx")
Originfilepath = os.path.join(filepath, "DTime醣時低醣DIY蛋糕粉上市前徵求搶先試用者.xlsx")

excel_DF = pd.read_excel(Originfilepath, header = None)
excel_DF = excel_DF.rename(columns = {0:"reason", 1:"products", 2:"machine", 3:"name", 4:"address", 5:"phone", 6:"mail"})
DF_711 = excel_DF[(excel_DF["address"].str.contains("711|7-11|7－11|7＿11|小金門市|7-ELEVEN|統一 道生|239042|112189|青建門市|新亞大門市|7—11|7_11"))]
DF_family = excel_DF[(excel_DF["address"].str.contains("全家|草屯稻豐店"))]
DF_ok = excel_DF[(excel_DF["address"].str.contains("OK"))]
DF_Hilife = excel_DF[(excel_DF["address"].str.contains("萊爾富"))]
DF_Others = excel_DF[excel_DF["address"].str.contains("711|7-11|全家|OK|萊爾富|7－11|7＿11|小金門市|7-ELEVEN|統一 道生|239042|112189|青建門市|新亞大門市|草屯稻豐店|7—11|7_11") == False] 

writer = pd.ExcelWriter(Newfilepath)
DF_711.to_excel(writer, sheet_name = "711", encoding = "utf-8-sig") 
DF_family.to_excel(writer, sheet_name = "全家", encoding = "utf-8-sig")
DF_ok.to_excel(writer, sheet_name = "OK", encoding = "utf-8-sig")
DF_Hilife.to_excel(writer, sheet_name = "Hilife", encoding = "utf-8-sig")
DF_Others.to_excel(writer, sheet_name = "others", encoding = "utf-8-sig")
writer.save()
